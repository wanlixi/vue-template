// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import lib from './assets/lib'
import './common-components'
import store from './store'
// 全部引入
// import ElementUi from 'element-ui'
// Vue.use(ElementUi)

// 按需引入  http://element.eleme.io/#/zh-CN/component/quickstart
// import 'element-ui/lib/theme-default/index.css'
// import { Form, FormItem, Select, Option, Checkbox, Button, DatePicker, Input, Col, TimePicker, Switch, RadioGroup, Radio,CheckboxGroup} from 'element-ui'

// Vue.use(Form)
// Vue.use(FormItem)
// Vue.use(Select)
// Vue.use(Option)
// Vue.use(Checkbox)
// Vue.use(Button)
// Vue.use(DatePicker)
// Vue.use(Input)
// Vue.use(TimePicker)
// Vue.use(Col)
// Vue.use(Switch)
// Vue.use(RadioGroup)
// Vue.use(Radio)
// Vue.use(CheckboxGroup)


Vue.config.productionTip = false
// Vue.prototype.$axios = api

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App }
})
