import * as types from './types'

const mutations = {
  [types.GET_USER_INFO] (state) {
    console.log(state.userInfo.userName)
    return state.userInfo
  },
  [types.GET_USER_FAVORITE] (state) {
    return state.userInfo.favorite
  },
  [types.ADD_FAVORITE] (state, newFavorite) {
    state.userInfo.favorite.push(newFavorite)
  }
  
}

export default mutations