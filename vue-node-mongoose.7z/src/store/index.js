import Vue from 'vue'
import Vuex from 'vuex'
import mutations from './mutations'
import * as actions from './actions'
Vue.use(Vuex)

export const state = {
  userInfo: {
    userName:'wanlixin',
    userId: 12,
    sex: 'man',
    city: 'shanghai',
    favorite: [
      'book',
      'movie',
      'game'
    ]
  }
}
const debug = process.env.NODE_ENV !== 'production'

const store = new Vuex.Store({
  state,
//   getters: {
//     getUserInfo (state) {
//       return state.userInfo.userName
//     }
//   },
  mutations,
  actions,
  // plugins: [debg ? ['createLogger()'] : []],
  // store分模块 aaa和bbb里面分别包含state/mutations/actions
  // modules: {a:aaa,b:bbb},
  strict:debug
  // getters,
});
export default store;