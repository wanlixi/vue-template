import * as types from './types'
export const GET_USER_INFO = ({commit}) => commit(types.GET_USER_INFO);
export const GET_USER_FAVORITE = ({commit}) => commit(types.GET_USER_FAVORITE);
export const ADD_FAVORITE = ({commit}, newFavorite) => commit(types.ADD_FAVORITE, newFavorite); 