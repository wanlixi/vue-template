<template>
  <div class="look-more" @click="clickLookMore" v-show="state">
    <Icon type="chevron-down"></Icon>
    <p class="look-more-text">点击查看更多内容</p>
  </div>
</template>
<script type="text/babel">
export default {
  data () {
    return {
      
    }
  },
  props: {
    stateType: true
  },
  computed: {
    state () {
      return this.stateType
    }
  },
  methods: {
    clickLookMore () {
      this.stateType = false
    }
  }
}
</script>
<style lang="stylus" scoped>
.look-more
  text-align center
</style>

