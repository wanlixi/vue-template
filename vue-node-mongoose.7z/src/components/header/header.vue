<template>
  <header>
    header
  </header>
</template>
<script type="text/babel">
  export default {
    data () {
      return {
        
      }
    }
  }
</script>
<style lang="stylus" scoped>

</style>

