
import Vue from 'vue'
// import axios from 'axios'
// import api from './api'

/**公共头***/
// import VHeader from './components/header/header.vue'
// Vue.component('VHeader', VHeader)
// import VNav from 'components/nav/nav.vue'
// Vue.component('VNav', VNav)
/**公共头***/

/**公共尾***/
// import VFooter from './components/footer/footer.vue'
// Vue.component('VFooter', VFooter)
/**公共弹窗***/
// import Popup from './components/popup/popup.vue'
// Vue.component('Popup', Popup)
/**公共尾***/

/**飘浮物***/
// import ErWeiMa from './components/erweima/erweima.vue'
// Vue.component('ErWeiMa', ErWeiMa)
// import QqChat from './components/qqchat/qqchat.vue'
// Vue.component('QqChat', QqChat)
/**飘浮物QQ弹窗***/
// import Qq from './components/popup/qq.vue'
// Vue.component('Qq', Qq)
/**飘浮物向上箭头***/
// import GoTop from './components/gotop/gotop.vue'
// Vue.component('GoTop', GoTop)

/**留言板***/
// import MessageBoard from './components/message-board/message-board.vue'
// Vue.component('MessageBoard', MessageBoard)

/**飘浮物***/

import {Icon, Message, Modal} from 'iview'
Vue.component('Icon', Icon)
Vue.prototype.$Message = Message
Vue.prototype.$Modal = Modal
// Vue.prototype.$api = api
