
var Rxports = {
	webName: "wanlixin",
	logo: ''	
};
module.exports = Rxports
