<template>
  <div class="index">
    index
  </div>
</template>

<script type="text/babel">
// import { mapActions , mapState, mapGetters, mapMutations } from 'vuex'
// import datePicker from 'vue-ios-datepicker'
export default {
  data () {
    return {
      
    }  
  },
  computed: {
    
  },
  mounted () {
    
  },
  methods: {
    
  }
}
</script>

<style lang="stylus" scoped>
</style>