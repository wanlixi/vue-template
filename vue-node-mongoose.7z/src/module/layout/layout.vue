<!-- 
【功能描述】：布局模板
 -->
<template>
  <div class="app">
    <!--<v-header></v-header> -->
    <div class="main">
      <router-view></router-view>
    </div>
    <!--<v-footer></v-footer> -->
    <!--<go-top></go-top>-->
  </div>
</template>
<script type="text/babel">
  export default {
    data () {
      return {

      }
    },
    props: {

    },
    methods: {
      
    }
  }
</script>