import Mock from 'mockjs'
import axios from 'axios'
import qs from 'qs'

axios.defaults.timeout = 5000;
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8';
// axios.defaults.baseUR = 'http://tpbb.com/api/'

//POST传参序列化
axios.interceptors.request.use((config) => {
    if(config.method  === 'post'){
        config.data = qs.stringify(config.data);
    }
    return config;
},(error) =>{
    return Promise.reject(error);
});

//返回状态判断
axios.interceptors.response.use((res) =>{
    if(res.status !== 200){
        return Promise.reject(res);
    }
    return res;
}, (error) => {
    return Promise.reject(error);
});

// 对axios二次封装
export function fetch(url, params) {
    return new Promise((resolve, reject) => {
        axios.post(url, params)
            .then(response => {
                resolve(response.data);
            }, err => {
                reject(err);
            })
            .catch((error) => {
               reject(error)
            })
    })
}

export default {
    getUserInfo() {
        return fetch('/user')
    },
    getFavorite(params) {
        return fetch('/favorite',params)
    }
}

Mock.mock('/user', 'post', {
// 属性 list 的值是一个数组，其中含有 1 到 10 个元素
  'list|1-10': [{
    // 属性 id 是一个自增数，起始值为 1，每次增 1
    'id|+1': 1,
    'name': '@name',
    'age|1-100': 100,
    'color': '@color'
  }]
}),
Mock.mock('/favorite', 'post', {
// 属性 list 的值是一个数组，其中含有 1 到 10 个元素
  'list|1-10': [{
    'email': '@email',
    'url': '@url'
  }]
})