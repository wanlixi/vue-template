import loadView from './async-view-loader'
// import app from './module/app.vue'
import Layout from './module/layout/layout.vue'



const routes = [
  {
    path:'/',
    component: Layout,
    children: [
      {
        path:'/',
        component: loadView(loaded => {
          require(['./module/index/index.vue'], loaded)
        }),
        title:'首页',
        //导航选中的索引,从0开始
        selectedIndex: 0,
        
      },
      {
        path:'/list',
        component: loadView(loaded => {
          require(['./module/list/list.vue'], loaded)
        }),
        title:'列表',
        //导航选中的索引,从0开始
        selectedIndex: 0,
        
      },
      {
        path:'/admin',
        component: loadView(loaded => {
          require(['./module/admin/admin.vue'], loaded)
        }),
        title:'后台',
        //导航选中的索引,从0开始
        selectedIndex: 0,
        
      },
      {
        path:'/detail',
        component: loadView(loaded => {
          require(['./module/detail/detail.vue'], loaded)
        }),
        title:'详情',
        //导航选中的索引,从0开始
        selectedIndex: 0,
        
      },
    ]
  }
];

export default routes
