<template>
  <router-view></router-view>
</template>

<script type="text/babel">
export default {
  name: 'app'
}
</script>

<style lang="stylus" scoped>

</style>
