import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

const state = {
    userInfo: {
        userName:'wanlixin',
        userId: 12,
        sex: 'man',
        city: 'shanghai',
        favorite: [
            'book',
            'movie',
            'game'
        ]
    }
}
const mutations = {
    GET_USER_INFO (state) {
        return state.userInfo
    },
    SET_USER_FAVORITE (state) {
        return state.userInfo.favorite
    },
    ADD_FAVORITE (state, newFavorite) {
        state.userInfo.favorite.push(newFavorite)
    }
}

const store = new Vuex.Store({
    state,
    mutations,
});
export default store;