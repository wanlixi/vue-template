export const GET_USER_INFO = ({dispatch}) => dispatch('GET_USER_INFO');
export const GET_USER_FAVORITE = ({dispatch}) => dispatch('GET_USER_FAVORITE');
export const ADD_FAVORITE = ({dispatch}, newFavorite) => dispatch('ADD_FAVORITE', newFavorite);